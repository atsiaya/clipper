<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('home_view');
	}
	
	public function test(){
	    
            $this->db->insert('logs', array('logs' => ""));
	}

    public function pay()
    {


        // $phone = $this->input->post('phone');
        // $amount = $this->input->post('amount');
        $amount = "1";
                $phone ="";


        $consumerKey = '0tWPbmRnyxTnTEA5AyOc0BEYE8gUAyrW';
        $consumerSecret = 'aME7ALG0Ebl9j6Wi';
        $url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        $credentials = base64_encode($consumerKey . ':' . $consumerSecret);

        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Authorization: Basic ' . $credentials));
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        $curl_response = curl_exec($curl);
        $feedback = json_decode($curl_response);
        $access_token = $feedback->access_token;
        curl_close($curl);

        if (is_null($access_token) == false) {


            $initiate_url = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';
            $AccountReference = 'Sercives goods';
            $TransactionDesc = 'Payment for goods via M-PESA.';
            $BusinessShortCode = '174379';
            $Timestamp = date('YmdHis');
            $PassKey = 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919';
            $Password = base64_encode($BusinessShortCode . $PassKey . $Timestamp);

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $initiate_url);
            
            
            $stkHeader = ['Content-Type:application/json', 'Authorization:Bearer ' . $access_token];
            curl_setopt($ch, CURLOPT_HTTPHEADER, $stkHeader);

            $curl_post_data = array(
                'BusinessShortCode' => $BusinessShortCode,
                'Password' => $Password,
                'Timestamp' => $Timestamp,
                'TransactionType' => 'CustomerPayBillOnline',
                'Amount' => $amount,
                'PartyA' => $phone,
                'PartyB' => $BusinessShortCode,
                'PhoneNumber' => $phone,
                'CallBackURL' => base_url().'/home/stkPushTransaction/',
                'AccountReference' => $AccountReference,
                'TransactionDesc' => $TransactionDesc
            );
            $data_string = json_encode($curl_post_data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
            $curl_response = curl_exec($ch);
            $ResponseDecoded = json_decode($curl_response);

//            echo $curl_response;

            if (!empty($ResponseDecoded)) {
                if (array_key_exists('errorMessage', $ResponseDecoded)) {

                    echo "00".$ResponseDecoded->errorMessage;


                } else {
                    if ($ResponseDecoded->ResponseCode === "0") {

                        echo "0";
                    } else {

                        echo "1";
                    }
                }
            }
        }
    }


    public function stkPushTransaction()
    {
        header("Content-Type:application/json");
       if (!$request = file_get_contents('php://input')) {
           
           
            $this->db->insert('logs', array('logs' => "Invalid input"));
        
            echo "Invalid input";
            exit();
        }
        $callbackJSONData = file_get_contents('php://input');
        $callbackData = json_decode($callbackJSONData);
       
         
     
            $this->db->insert('logs', array('logs' =>$callbackJSONData));
        
        
        $resultCode = $callbackData->Body->stkCallback->ResultCode;
        $resultDesc = $callbackData->Body->stkCallback->ResultDesc;
        $merchantRequestID = $callbackData->Body->stkCallback->MerchantRequestID;
        $checkoutRequestID = $callbackData->Body->stkCallback->CheckoutRequestID;
        $amount = $callbackData->Body->stkCallback->CallbackMetadata->Item[0]->Value;
        $mpesaReceiptNumber = $callbackData->Body->stkCallback->CallbackMetadata->Item[1]->Value;
        // $balance = $callbackData->Body->stkCallback->CallbackMetadata->Item[2]->Value;
        $transactionDate = $callbackData->Body->stkCallback->CallbackMetadata->Item[3]->Value;
        $phoneNumber = $callbackData->Body->stkCallback->CallbackMetadata->Item[4]->Value;

        date_default_timezone_set('Africa/Nairobi');

        $date = date('Y-m-d');
        $time = date('H:i:s');
        $finaltime = $date . ' at ' . $time;
        $this->db->trans_start();
        $entries = array(
            'response_code' => $resultCode,
            'response_message' => $resultDesc,
            'time' => $finaltime,
            'phone' => $phoneNumber,
            'amount' => $amount,
            'transaction_code' => $mpesaReceiptNumber
        );


        $this->db->insert('payment', $entries);

        $this->db->trans_complete();
        
       

        if ($this->db->trans_status() === FALSE) {
            $this->db->insert('logs', array('logs' => $this->db->error()));
        }

    }

}
