<?php
/**
 * Created by PhpStorm.
 * User: Martin
 * Date: 2/4/2020
 * Time: 3:44 AM
 */
?>
<!doctype html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Sp_Link</title>
    <link rel="shortcut icon" href="http://safepal.co.ke/splink/images/favicon.ico"/>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">

    <link rel="shortcut icon" href="http://safepal.co.ke/splink/images/favicon.ico"/>
    <!-- Styles -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
          integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <style lang="scss">
        html, body {
            background-color: #ffee;
            color: #666;
            font-family: 'Nunito', sans-serif;
            font-weight: 200;
            height: 100vh;
            margin: 0;
        }

        body {
            padding: 1rem;
            color: hsla(215, 5%, 50%, 1);
        }

        h1 {
            color: hsla(215, 5%, 10%, 1);
            margin-bottom: 2rem;
        }

        section {
            display: flex;
            flex-flow: row wrap;
        }

        section > div {
            flex: 1;
            padding: 0.5rem;
        }

        input[type="radio"] {
            display: none;

        &
        :not(:disabled) ~ label {
            cursor: pointer;
        }

        &
        :disabled ~ label {
            color: hsla(150, 5%, 75%, 1);
            border-color: hsla(150, 5%, 75%, 1);
            box-shadow: none;
            cursor: not-allowed;
        }

        }
        label {
            height: 100%;
            display: block;
            background: white;
            border: 2px solid hsla(150, 75%, 50%, 1);
            border-radius: 20px;
            padding: 1rem;
            margin-bottom: 1rem;
        / / margin: 1 rem;
            text-align: center;
            box-shadow: 0px 3px 10px -2px hsla(150, 5%, 65%, 0.5);
            position: relative;
        }

        input[type="radio"]:checked + label {
            background: #358f6e;
            color: hsla(215, 0%, 100%, 1);
            box-shadow: 0px 0px 20px hsla(150, 100%, 50%, 0.75);

        &
        ::after {
            color: hsla(215, 5%, 25%, 1);
            font-family: FontAwesome;
            border: #03cbfc;
            content: "\f00c";
            font-size: 24px;
            position: absolute;
            top: -25px;
            left: 50%;
            transform: translateX(-50%);
            height: 50px;
            width: 50px;
            line-height: 50px;
            text-align: center;
            border-radius: 50%;
            background: white;
            box-shadow: 0px 2px 5px -2px hsla(0, 0%, 0%, 0.25);
        }

        }
        input[type="radio"]#5:checked + label {
            background: cyan;
            border-color: cyan;
        }

        p {
            font-weight: 400;
        }

        span {
            font-weight: 300;
            font-size: 20px;
        }

        @media  only screen and (max-width: 700px) {
            section {
                flex-direction: column;
            }
        }

        .full-height {
            height: 100vh;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .links > a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        a {
            font-weight: 600;
            font-style: italic;
            font-size: 15px;
        }

        .m-b-md {
            margin-bottom: 30px;
        }

        .wrap-collabsible {
            margin-bottom: 1.2rem 0;
        }

        input[type='checkbox'] {
            display: none;
            font-family: FontAwesome;
        }

        .lbl-toggle {
            display: block;

            font-weight: bold;
            font-family: monospace;
            font-size: 1.2rem;
            text-transform: uppercase;
            text-align: center;

            padding: 1rem;

            color: #163a2d;
            background: #45baa5;

            cursor: pointer;

            border-radius: 7px;
            transition: all 0.25s ease-out;
        }

        .lbl-toggle:hover {
            color: #06100c;
            background: #358f6e;
        }

        .lbl-toggle::before {
            content: ' ';
            display: inline-block;

            border-top: 5px solid transparent;
            border-bottom: 5px solid transparent;
            border-left: 5px solid currentColor;
            vertical-align: middle;
            margin-right: .7rem;
            transform: translateY(-2px);

            transition: transform .2s ease-out;
        }

        .toggle:checked + .lbl-toggle::before {
            transform: rotate(90deg) translateX(-3px);
        }

        .collapsible-content {
            max-height: 0px;
            overflow: hidden;
            transition: max-height .25s ease-in-out;
        }

        .toggle:checked + .lbl-toggle + .collapsible-content {
            max-height: 3500px;
        }

        .toggle:checked + .lbl-toggle {
            border-bottom-right-radius: 3px;
            border-bottom-left-radius: 3px;
        }

        .collapsible-content .content-inner {
            background: #ffffff;
            border-bottom-left-radius: 7px;
            border-bottom-right-radius: 7px;
            padding: .5rem 1rem;
        }

        .leading-input {
            width: 50px;
            border: 1px solid;
            height: 30px;
            /*position: absolute;*/
            background: #eeeeee;
            padding-right: 6px;
            padding-left: 6px;
            padding-top: 4px;
            padding-bottom: 4px;
            font-weight: bold;
            display: inline;
            vertical-align: middle;
            cursor: not-allowed;
            color: #555555;
        }

        .follower-input {
            margin: 0 auto;
            border: 2px solid;
            height: 30px;
            vertical-align: middle;
            background: #ffffff;
        }

        .phone_number {
            display: table-row;
            position: relative;
        }
        .site-bg {
            position: fixed;
            height: 100%;
            width: 100%;
            z-index: 0;
            background-image: url(../images/bg.jpg);
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .site-bg-overlay {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: 1;
            background: rgba(120, 80, 120, 0.2);
        }
    </style>
    <script type="text/javascript">
        function disabled() {
            alert('This device has Access!')
        }
        //        function toggleChecked(){
        //            document.getElementById('voucher').disabled = !document.getElementById('voucher').disabled;
        //            document.getElementById('voucher2').disabled = !document.getElementById('voucher2').disabled;
        //        }

        $( document ).ready(function() {
            $("#formPayment").submit(function(e) {

                e.preventDefault(); // avoid to execute the actual submit of the form.


                var phoneNumber = $('#phone').val();

                var amount = $("input[name='package']:checked"). val();

                $.ajax({
                    type:'POST',
                    url: '<?php echo base_url();?>/home/'+phoneNumber+'/'+amount,
                    success:function(data){
                        // console.log(ida);
                        console.log('passed');
                        console.log(data);
                    }
                });
                // var url = "http://airtime.safepal.co.ke/checkout/pay.php/?phone="+phoneNumber+"&&amount="+amount;
                //
                // window.location.href = url;


            });
        });

    </script>
</head>
<body class="container">
<div class="card-body mb-5">


    <!-- fa pls -->
    <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">

    <!-- animate.css -->
    <link href="https://s3-us-west-2.amazonaws.com/s.cdpn.io/67239/animate.min.css" rel="stylesheet" />

    <!-- under overlay stuff -->
    <div class="body"></div>

    <!-- the panel -->
    <style>
        #text{
            position: absolute;
            top: 10%;
            left: 10%;
            font-size: 1px;
            color: black;
            transform: translate(-20%,-20%);
            -ms-transform: translate(-20%,-20%);
        }
    </style>
    <get dem fancy typefaces -->
        <script type="text/javascript" src="//use.typekit.net/psm0wvc.js"></script>
        <script type="text/javascript">try{Typekit.load();}catch(e){}</script>

        <!--//action="/checkout/pay.php"-->

        <form method="post" id="formPayment"  class="form card-body">
            <input type="hidden" name="_token" value="cuP5502uEV0I4fr1CnKZwgOaFxSa1haAeBFae0dK">        <div class="form-row">
                <input type="hidden" name="mac" value="user">
                <input type="hidden" name="ap" value="78:8a:20:23:47:33">



                <div class="card content">
                    <input class="toggle" type="checkbox">
                    <label class="lbl-toggle">Choose Unlimited Package of choice</label>
                    <div class="content">
                        <div class="content-inner">
                            <section>
                                <div>
                                    <input type="radio" id="1" name="package" value="20" required>
                                    <label for="1">
                                        <h2>2 Hours Unlimited</h2>

                                        <span>Ksh.20</span>
                                    </label>
                                </div>
                                <div>
                                    <input type="radio" id="2" name="package" value="35">
                                    <label for="2">
                                        <h2>4 Hours Unlimited</h2>

                                        <span>Ksh.35</span>
                                    </label>
                                </div>
                                <div>
                                    <input type="radio" id="3" name="package" value="50" checked >
                                    <label for="3">
                                        <h2>6 Hours Unlimited</h2>

                                        <span>Ksh.50</span>
                                    </label>
                                </div>
                                <div>
                                    <input type="radio" id="4" name="package" value="70">
                                    <label for="4">
                                        <h2>12 Hours Unlimited</h2>

                                        <span>Ksh.70</span>
                                    </label>
                                </div>
                                <div>
                                    <input type="radio" id="5" name="package" value="100">
                                    <label for="5">
                                        <h2>24 Hours Unlimited</h2>
                                        <p>Whole day Connected </p>
                                        <span>Ksh.100</span>
                                    </label>
                                </div>
                                <div>
                                    <input type="radio" id="6" name="package" value="400">
                                    <label for="6">
                                        <h2>Weekly Unlimited</h2>
                                        <p>Whole Week Connected</p>
                                        <span>Ksh.400</span>
                                    </label>
                                </div>


                            </section>
                        </div>
                    </div>
                </div>





                <div class="text-center hidden-sm hidden-xs">
                    <input type="radio" id="access" name="purpose" value="ACCESS">
                    <label for="access" class="btn btn-default m-2">
                        <span>Connect</span>
                    </label>

                </div>



                <div class="form-group col-md-12 row mb-3 col-sm-7">
                    <h3>Enter Mobile Number:</h3>
                    <div class="">
                        <input type="tel" name="phone" id="phone" class="form-control" placeholder="2547xxxxxxxxx" value="254" required/>
                    </div>
                </div>
                <br>
                <div class="form-group form-row mb-3 flex-row">
                    <button type="submit" class="btn btn-lg btn-primary">Buy</button>
                </div>

            </div>

            <div class="card-footer col-md-12 flex-center mt-5">
                <footer class="text-sm-center text-center">Any troubles? Contact through<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
                    <a href="https://api.whatsapp.com/send?phone=254780117496&text=Hi! Kindly .......%21%20." class="float" target="_blank">WhatsApp
                        <i class="fa fa-whatsapp my-float"></i>
                    </a></footer>
            </div>
</body>

</html>
